package com.lunavpn.app.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lunavpn.app.model.VpnServer
import com.lunavpn.app.viewmodel.VpnViewModel

@Composable
fun MainScreen(viewModel: VpnViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = uiState.currentTab == 0,
                    onClick = { viewModel.changeTab(0) },
                    icon = { Icon(Icons.Filled.VpnLock, "Connect") },
                    label = { Text("ติดต่อ") }
                )
                NavigationBarItem(
                    selected = uiState.currentTab == 1,
                    onClick = { viewModel.changeTab(1) },
                    icon = { Icon(Icons.Filled.Public, "Servers") },
                    label = { Text("ซ่อมแซม") }
                )
                NavigationBarItem(
                    selected = uiState.currentTab == 2,
                    onClick = { viewModel.changeTab(2) },
                    icon = { Icon(Icons.Filled.Speed, "Speed") },
                    label = { Text("ทดสอบ") }
                )
                NavigationBarItem(
                    selected = uiState.currentTab == 3,
                    onClick = { viewModel.changeTab(3) },
                    icon = { Icon(Icons.Filled.Settings, "Settings") },
                    label = { Text("การตั้งค่า") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (uiState.currentTab) {
                0 -> HomeScreen(uiState, viewModel)
                1 -> ServersScreen(uiState, viewModel)
                2 -> SpeedTestScreen(uiState)
                3 -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(uiState: VpnUiState, viewModel: VpnViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        
        // Logo
        Text(
            "🌙 LUNA VPN",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1976D2)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Connection Button
        Button(
            onClick = {
                val server = uiState.selectedServer ?: uiState.servers.first()
                if (uiState.isConnected) {
                    viewModel.disconnect()
                } else {
                    viewModel.connectToServer(server)
                }
            },
            modifier = Modifier
                .size(120.dp),
            shape = MaterialTheme.shapes.medium,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (uiState.isConnected) Color(0xFF4CAF50) else Color(0xFF1976D2)
            )
        ) {
            Text(
                if (uiState.isConnected) "✓" else "▶",
                fontSize = 48.sp,
                color = Color.White
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            if (uiState.isConnected) "เชื่อมต่ออยู่" else "ไม่ได้เชื่อมต่อ",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Server Info
        if (uiState.selectedServer != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "เซิร์ฟเวอร์ปัจจุบัน",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        "${uiState.selectedServer!!.flag} ${uiState.selectedServer!!.city}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        uiState.selectedServer!!.protocol,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Speed Display
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Card(modifier = Modifier.weight(1f).padding(4.dp)) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("📥", fontSize = 24.sp)
                    Text("ลง", fontSize = 10.sp, color = Color.Gray)
                    Text(uiState.speedDown, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
            Card(modifier = Modifier.weight(1f).padding(4.dp)) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("📤", fontSize = 24.sp)
                    Text("ขึ้น", fontSize = 10.sp, color = Color.Gray)
                    Text(uiState.speedUp, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Usage
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ข้อมูลที่ใช้: ${uiState.dataUsed} / ${uiState.dataLimit}", fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = 0.3f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                )
            }
        }
    }
}

@Composable
fun ServersScreen(uiState: VpnUiState, viewModel: VpnViewModel) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("ค้นหาเซิร์ฟเวอร์...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                trailingIcon = { Icon(Icons.Filled.Search, null) }
            )
        }
        
        items(uiState.servers.size) { index ->
            ServerItem(
                server = uiState.servers[index],
                isSelected = uiState.selectedServer?.id == uiState.servers[index].id,
                onSelect = { viewModel.selectServer(it) }
            )
        }
    }
}

@Composable
fun ServerItem(server: VpnServer, isSelected: Boolean, onSelect: (VpnServer) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(server.flag, fontSize = 24.sp)
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                Text(
                    "${server.country} - ${server.city}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    server.protocol,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Text(
                    "Ping: ${server.ping} | ${server.maxSpeed}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
            RadioButton(selected = isSelected, onClick = { onSelect(server) })
        }
    }
}

@Composable
fun SpeedTestScreen(uiState: VpnUiState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🚀 ทดสอบความเร็ว", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(onClick = {}) {
            Text("เริ่มทดสอบ")
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("⚙️ การตั้งค่า", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        
        Card {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Text("เกี่ยวกับ", fontWeight = FontWeight.Bold)
                Text("Luna VPN v1.0.0", color = Color.Gray)
            }
        }
    }
}

// Import for LazyColumn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.TextField
import com.lunavpn.app.viewmodel.VpnUiState
