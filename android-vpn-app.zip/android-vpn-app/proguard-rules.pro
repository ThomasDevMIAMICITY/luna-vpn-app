-keep class * extends java.util.ListResourceBundle {
    protected Object[][] getContents();
}

-keep public class * extends android.content.Context
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service

-keepclasseswithmembernames class * {
    native <methods>;
}

-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
}

-keep public class * extends androidx.lifecycle.ViewModel
-keep public class * extends androidx.viewmodel.ViewModelProvider

-keepattributes InnerClasses
-keepattributes EnclosingMethod
