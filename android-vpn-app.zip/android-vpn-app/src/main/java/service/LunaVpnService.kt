package com.lunavpn.app.service

import android.net.VpnService
import android.content.Intent

class LunaVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = Builder()
        builder.setSession("Luna VPN")
        builder.addAddress("10.0.0.2", 32)
        builder.addRoute("0.0.0.0", 0)
        builder.addDnsServer("8.8.8.8")
        builder.addDnsServer("8.8.4.4")
        
        val vpnInterface = builder.establish()
        
        return START_STICKY
    }
    
    override fun onDestroy() {
        super.onDestroy()
    }
}
