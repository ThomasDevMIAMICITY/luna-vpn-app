package com.lunavpn.app.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Public

data class VpnServer(
    val id: String,
    val country: String,
    val countryCode: String,
    val city: String,
    val protocol: String,
    val maxSpeed: String,
    val ping: Int,
    val flag: String,
    val status: ConnectionStatus = ConnectionStatus.OPEN,
    val users: Int = 0
)

enum class ConnectionStatus {
    OPEN,
    FAST,
    SLOW,
    FULL
}

object SampleServers {
    val servers = listOf(
        VpnServer(
            id = "ais-play-01",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "Open",
            maxSpeed = "100 Mbps",
            ping = 247,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "ais-isan-01",
            country = "Thailand",
            countryCode = "TH",
            city = "Isan",
            protocol = "Open, SSH",
            maxSpeed = "100 Mbps",
            ping = 257,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "ais-isan-02",
            country = "Thailand",
            countryCode = "TH",
            city = "Isan",
            protocol = "Open, SSH",
            maxSpeed = "100 Mbps",
            ping = 257,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "dtac-gaming",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SSH",
            maxSpeed = "100 Mbps",
            ping = 269,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "dtac-nopro",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SlowDNS",
            maxSpeed = "15 Mbps",
            ping = 200,
            flag = "🇹🇭",
            status = ConnectionStatus.SLOW
        ),
        VpnServer(
            id = "dtac-social",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SSH",
            maxSpeed = "100 Mbps",
            ping = 217,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "true-id",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SSH",
            maxSpeed = "100 Mbps",
            ping = 256,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "my-nopro",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SlowDNS",
            maxSpeed = "15 Mbps",
            ping = 198,
            flag = "🇹🇭",
            status = ConnectionStatus.SLOW
        ),
        VpnServer(
            id = "true-export",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "Open",
            maxSpeed = "100 Mbps",
            ping = 207,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        ),
        VpnServer(
            id = "true-trueid",
            country = "Thailand",
            countryCode = "TH",
            city = "Bangkok",
            protocol = "SSH",
            maxSpeed = "100 Mbps",
            ping = 200,
            flag = "🇹🇭",
            status = ConnectionStatus.OPEN
        )
    )
}
