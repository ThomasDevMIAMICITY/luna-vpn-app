package com.lunavpn.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lunavpn.app.model.VpnServer
import com.lunavpn.app.model.SampleServers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class VpnUiState(
    val isConnected: Boolean = false,
    val selectedServer: VpnServer? = null,
    val dataUsed: String = "0 B",
    val dataLimit: String = "1,024 MB",
    val connectionTime: String = "00:00:00",
    val speedDown: String = "0 Mbps",
    val speedUp: String = "0 Mbps",
    val servers: List<VpnServer> = SampleServers.servers,
    val currentTab: Int = 0
)

class VpnViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(VpnUiState())
    val uiState: StateFlow<VpnUiState> = _uiState.asStateFlow()

    fun connectToServer(server: VpnServer) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isConnected = true,
                selectedServer = server
            )
            startSpeedSimulation()
        }
    }

    fun disconnect() {
        _uiState.value = _uiState.value.copy(
            isConnected = false,
            speedDown = "0 Mbps",
            speedUp = "0 Mbps"
        )
    }

    fun changeTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(currentTab = tabIndex)
    }

    fun selectServer(server: VpnServer) {
        _uiState.value = _uiState.value.copy(selectedServer = server)
    }

    private fun startSpeedSimulation() {
        viewModelScope.launch {
            for (i in 1..10) {
                kotlinx.coroutines.delay(500)
                val speedDown = (Math.random() * 100).toInt()
                val speedUp = (Math.random() * 50).toInt()
                
                _uiState.value = _uiState.value.copy(
                    speedDown = "$speedDown Mbps",
                    speedUp = "$speedUp Mbps"
                )
            }
        }
    }
}
