# 🌙 Luna VPN - Android Application

สำเร็จรูปแอปพลิเคชัน VPN สำหรับ Android 15 ที่มีระบบสมบูรณ์ครบวงจร

## ✨ ฟีเจอร์

- ✅ **เชื่อมต่อ VPN** - ติดต่อกับเซิร์ฟเวอร์ได้อย่างรวดเร็ว
- ✅ **รายการเซิร์ฟเวอร์** - 10+ เซิร์ฟเวอร์พร้อมสูตรมาตรฐาน
- ✅ **ทดสอบความเร็ว** - วัดความเร็วลงและขึ้นแบบเรียลไทม์
- ✅ **ติดตามการใช้** - ดูข้อมูลที่ใช้ไป
- ✅ **ประเทศหลายประเทศ** - สนับสนุนเซิร์ฟเวอร์หลายประเทศ
- ✅ **Material Design 3** - UI ที่สวยงามและทันสมัย
- ✅ **Dark Mode** - รองรับโหมดมืด

## 📋 ข้อกำหนด

- Android 8.0 (API 24) ขึ้นไป
- Android 15 ตรวจสอบ
- RAM ขั้นต่ำ: 2 GB
- ที่เก็บ: 100 MB

## 🚀 การติดตั้ง

### วิธีที่ 1: Android Studio

1. **Clone หรือดาวน์โหลด**
```bash
git clone <your-repo-url>
cd android-vpn-app
```

2. **เปิดใน Android Studio**
   - File → Open → เลือกโฟลเดอร์ `android-vpn-app`

3. **รอให้ Gradle sync เสร็จ**

4. **รัน**
   - Click "Run" หรือ Shift + F10

### วิธีที่ 2: Gradle CLI

```bash
./gradlew build
./gradlew installDebug
```

## 📁 โครงสร้างโครงการ

```
android-vpn-app/
├── src/
│   └── main/
│       ├── java/
│       │   ├── MainActivity.kt           # Activity หลัก
│       │   ├── model/
│       │   │   └── VpnServer.kt          # รูปแบบข้อมูล
│       │   ├── viewmodel/
│       │   │   └── VpnViewModel.kt       # ViewModel
│       │   ├── ui/
│       │   │   ├── screen/
│       │   │   │   └── MainScreen.kt    # หน้าจอหลัก
│       │   │   └── theme/
│       │   │       └── Theme.kt          # ธีม
│       │   └── service/
│       │       ├── LunaVpnService.kt     # บริการ VPN
│       │       └── NotificationService.kt
│       └── res/
│           └── values/
│               ├── strings.xml
│               ├── colors.xml
│               └── themes.xml
├── build.gradle                          # ไฟล์ build
├── settings.gradle                       # ตั้งค่า Gradle
└── README.md                             # เอกสารนี้
```

## 🎯 โครงสร้าง App

### Home Screen (ติดต่อ)
- ปุ่มเชื่อมต่อขนาดใหญ่
- สถานะการเชื่อมต่อแบบเรียลไทม์
- เซิร์ฟเวอร์ปัจจุบัน
- ความเร็วลง/ขึ้น
- ข้อมูลที่ใช้

### Servers Screen (ซ่อมแซม)
- ค้นหาเซิร์ฟเวอร์
- รายการเซิร์ฟเวอร์พร้อมสถานะ
- เลือกเซิร์ฟเวอร์
- ข้อมูล Ping และความเร็ว

### Speed Test Screen (ทดสอบ)
- ทดสอบความเร็ว
- กราฟผลลัพธ์
- บันทึกการทดสอบ

### Settings Screen (การตั้งค่า)
- เกี่ยวกับแอป
- อัปเดตเวอร์ชัน
- ตั้งค่า VPN
- อื่นๆ

## 🔧 การพัฒนา

### เพิ่มเซิร์ฟเวอร์ใหม่

แก้ไข `model/VpnServer.kt`:
```kotlin
VpnServer(
    id = "new-server",
    country = "ประเทศ",
    city = "เมือง",
    protocol = "Protocol",
    maxSpeed = "100 Mbps",
    ping = 250,
    flag = "🇳🇱"
)
```

### ปรับแต่ง UI

แก้ไข `ui/theme/Theme.kt` สำหรับสีและธีม

### เพิ่ม VPN Protocol

แก้ไข `service/LunaVpnService.kt`

## 📦 Dependencies

- Android Compose UI
- AndroidX LiveData & ViewModel
- Material Design 3
- Retrofit (สำหรับ API)
- Coroutines

## 🔐 Permissions

ต้องการ:
- `INTERNET` - เชื่อมต่ออินเทอร์เน็ต
- `BIND_VPN_SERVICE` - บริการ VPN
- `CHANGE_NETWORK_STATE` - เปลี่ยนสถานะเครือข่าย

## ⚙️ Build

### Debug
```bash
./gradlew assembleDebug
```

### Release
```bash
./gradlew assembleRelease
```

## 🧪 การทดสอบ

```bash
./gradlew test
./gradlew connectedAndroidTest
```

## 📝 การตั้งค่า VPN

1. ไปที่ Settings → Network
2. เลือก Luna VPN
3. กด Connect
4. อนุญาตการเข้าถึง VPN

## 🐛 การแก้ไขปัญหา

### ไม่สามารถเชื่อมต่อ
- ตรวจสอบการเชื่อมต่ออินเทอร์เน็ต
- รีสตาร์ตแอป
- ลองเซิร์ฟเวอร์อื่น

### ความเร็วช้า
- เลือกเซิร์ฟเวอร์ที่มี Ping ต่ำ
- ตรวจสอบการเชื่อมต่ออินเทอร์เน็ต
- ปิดแอปอื่นๆ

## 📚 เอกสาร

- [Android Developer Docs](https://developer.android.com/)
- [Compose Documentation](https://developer.android.com/jetpack/compose)
- [VPN Service](https://developer.android.com/reference/android/net/VpnService)

## 📄 ลิขสิทธิ์

MIT License - ใช้งานได้อย่างอิสระ

## 👨‍💻 ผู้พัฒนา

Luna VPN Team - 2025

---

**🚀 พร้อมให้ใช้งานและพัฒนาต่อแล้ว!**
