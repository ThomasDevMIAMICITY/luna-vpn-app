# 📚 คู่มือการตั้งค่า Luna VPN

## การติดตั้ง Android Studio

### Windows
1. ดาวน์โหลด [Android Studio](https://developer.android.com/studio)
2. รันตัวติดตั้ง
3. ติดตั้ง Android SDK

### Mac
1. ดาวน์โหลด Android Studio สำหรับ Mac
2. ลาก Android Studio ไปยัง Applications
3. เปิดและติดตั้ง SDK

### Linux
```bash
# Ubuntu/Debian
sudo apt-get install android-studio

# Fedora
sudo dnf install android-studio
```

---

## การเปิดโครงการใน Android Studio

### ขั้นตอน 1: โคลนโครงการ
```bash
git clone https://github.com/yourusername/luna-vpn.git
cd luna-vpn/android-vpn-app
```

### ขั้นตอน 2: เปิด Android Studio
- File → Open Project
- เลือกโฟลเดอร์ `android-vpn-app`
- รอให้ Gradle sync เสร็จ

### ขั้นตอน 3: ตั้งค่า Emulator (ไม่บังคับ)
1. Tools → AVD Manager
2. สร้าง Virtual Device ใหม่
3. เลือก Android 15 (API 34)
4. ตั้งค่า RAM & Storage

### ขั้นตอน 4: รัน
- Click "Run" บน Toolbar
- เลือก Emulator หรือ Device จริง
- รอให้โหลดเสร็จ

---

## การแก้ไขค่าคุณสมบัติ

### ไฟล์ที่ต้องแก้ไข
1. `build.gradle` - เวอร์ชันและ Dependencies
2. `AndroidManifest.xml` - Permissions
3. `MainActivity.kt` - Logic หลัก
4. `model/VpnServer.kt` - เซิร์ฟเวอร์

---

## การเพิ่มเซิร์ฟเวอร์

แก้ไข `model/VpnServer.kt`:

```kotlin
data class VpnServer(
    val id: String,
    val country: String,
    val city: String,
    val flag: String,
    val protocol: String,
    val maxSpeed: String,
    val ping: Int
)
```

เพิ่มในรายการเซิร์ฟเวอร์:
```kotlin
object SampleServers {
    val servers = listOf(
        VpnServer(
            id = "custom-01",
            country = "ประเทศคุณ",
            city = "เมืองคุณ",
            flag = "🇹🇭",
            protocol = "SSH",
            maxSpeed = "100 Mbps",
            ping = 50
        )
    )
}
```

---

## การเพิ่มฟีเจอร์ใหม่

### สร้าง Screen ใหม่
1. สร้างไฟล์ใน `ui/screen/`
2. เขียน Composable function
3. เพิ่มไปใน `MainScreen.kt`
4. เพิ่ม Navigation item

ตัวอย่าง:
```kotlin
@Composable
fun NewFeatureScreen() {
    Column {
        Text("ฟีเจอร์ใหม่")
    }
}
```

### เพิ่มไปใน Navigation
```kotlin
when (uiState.currentTab) {
    0 -> HomeScreen()
    1 -> ServersScreen()
    2 -> SpeedTestScreen()
    3 -> NewFeatureScreen()  // เพิ่มที่นี่
    4 -> SettingsScreen()
}
```

---

## Build และปล่อยตัว

### Debug Build
```bash
./gradlew assembleDebug
```

### Release Build
```bash
./gradlew assembleRelease
```

### ลง APK ไปยัง Device
```bash
./gradlew installDebug
```

---

## ปัญหาทั่วไป

### 1. Gradle Sync ล้มเหลว
- ลบ `.gradle` folder
- ลบ `build` folder
- Sync ใหม่

### 2. Build ล้มเหลว
- ตรวจสอบ Java version
- Update Android SDK
- ล้าง Cache

### 3. Emulator ไม่เรียบ
- ใช้ Device จริง
- เพิ่ม RAM ให้ Emulator
- ใช้ Hardware Acceleration

---

## เพิ่มเติม

- [Android Developer Guide](https://developer.android.com/guide)
- [Compose Tutorial](https://developer.android.com/codelabs/jetpack-compose-intro)
- [VPN Guide](https://developer.android.com/reference/android/net/VpnService)

---

**✅ พร้อมที่จะเริ่มพัฒนาแล้ว!**
